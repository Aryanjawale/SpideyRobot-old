![SpideyRobot](https://telegra.ph/file/167c1367fbdccd3e99678.jpg) 

## Spidey Robot

<p align='center'>
  <img src="https://img.shields.io/github/forks/dcownerno1/SpideyRobot?style=flat-square" alt="Forks">
  <img src="https://img.shields.io/github/stars/dcownerno1/SpideyRobot?style=flat-square" alt="Stars">
  <img src="https://img.shields.io/github/issues/dcownerno1/SpideyRobot?style=flat-square" alt="Issues">
  <img src="https://img.shields.io/github/license/dcownerno1/SpideyRobot?style=flat-square" alt="LICENSE">
  <img src="https://img.shields.io/github/contributors/dcownerno1/SpideyRobot?style=flat-square" alt="Contributors">
  <img src="https://img.shields.io/github/repo-size/dcownerno1/SpideyRobot?style=flat-square" alt="Repo Size">
  <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/dcownerno1/SpideyRobot&amp;title=Profile%20Views" alt="Views">
</p>

<p align="center">
  <a href="https://www.python.org">
    <img src="http://ForTheBadge.com/images/badges/made-with-python.svg">

  </a>
</p>


**Telegram best Group Management bot made by [python](https://python.org) with more functions and speciality.**

## **Features :**
- Modern
- Fast
- Fully asynchronous
- Fully open-source
- Frequently updated

### You can easily find Spidey on Telegram .

<p align='left'>
 <a href="https://telegram.dog/SpideyRobot"><img src="https://img.shields.io/badge/SpideyRobot-2CA5E0?style=for-the-badge&amp;logo=telegram&amp;logoColor=white" alt="Find on Telegram"></a></br></br>

</p>

### Deploy to Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/dcownerno1/SpideyRobot)

If all works well, bot should send message to the **MESSAGE_DUMP** Group .

# ❤️ Support
<a href="https://t.me/PigasusUpdates"><img src="https://img.shields.io/badge/Join-Telegam%20Channel-red.svg?logo=Telegram"></a>
<a href="https://t.me/PigasusSupport"><img src="https://img.shields.io/badge/Join-Telegram%20Group-blue.svg?logo=telegram"></a>

### © Copyright 

#### Copyright (C) 2021-2022 by DC Owner ❤️️
#### Licensed under the terms of the GPL-3.0 License .

## Developer 💻 

[![DCOWNER](https://img.shields.io/badge/DC-OWNER-red?style=for-the-badge&logo=appveyor)](https://t.me/DreamerNo1) 

##### Powered by [@PigasusUpdates](https://telegram.dog/PigasusUpdates)


